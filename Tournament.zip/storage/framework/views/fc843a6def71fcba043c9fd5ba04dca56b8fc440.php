 
      <?php echo $__env->make('team-rep/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('team-rep/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container">
                
          <div class="container eventInfoClass">
    <h1 style="text-align: center;">TOURNAMENTS SCHEDULE</h1>
    <table id="eg_table" class="table">
         <thead>
            <tr>
                <th>Event Date</th>
                <th>Event Title</th>
                <th>Registered Teams</th>
                <th>Registered Status</th>
               <th></th>
            </tr>
        </thead>
        <tbody>
       <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href=""><?php echo e($tournament->tournament_date); ?></a></td>
                <td><a href="<?php echo e(url('/Event')); ?>"><?php echo e($tournament->tournament_name); ?></a></td>
                <td><a href="<?php echo e(url('/Event')); ?>"><?php echo e($tournament->team_name); ?></a></td>
                
                <td>
                <a href="">Incomplete</a>
                </td>

                 <td>
                 <a href="<?php echo e(url('/Singleteam')); ?>">
                <img class="edit teamstatusclass" src='<?php echo e(URL::asset("images/RedDot.png")); ?>' title="edit" alt="edit">
                </a>
                <!--<a href="#">
                <img class="delete" src="images/cancel.png"   title="delete" alt="delete">-->
                </a>
                </a>
                </td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
           
         
        </tbody>

      </table>
        
    </div>
    </div>

    <footer>
    </footer>   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
