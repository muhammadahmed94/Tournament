<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Hello <?php echo $user->name;?></div>

                <div class="panel-body">


 <form action="/uploadImage" method="post" enctype="multipart/form-data">
 <div class="container" style="padding-bottom:30px;">
  
  <div class="col-md-offset-1" style="heigth:400px;width:500px;padding-bottom:30px;" >
 <img  style="heigth:400px;width:500px" src="<?php echo e($user->imagepath); ?>"/>
 </div>
 Name :<input name="name" value="<?php echo e($user->name); ?>"> <br>
 Email : <input name="email" value="<?php echo e($user->name); ?>"><br>
 Last Updated at : <?php echo $user->updated_at;?>

 
 </div>
     <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <input type="file" name="userImage" class="form-control" id="image">
  </div>
  <button type="submit" class="btn btn-default">Submit</button>
</form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>