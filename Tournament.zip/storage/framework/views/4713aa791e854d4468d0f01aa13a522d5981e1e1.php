
    <?php echo $__env->make('team-rep/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('team-rep/sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container  eventInfoClass">
         <div class="container">
    <h1 style="text-align: center;">My Teams</h1>
    <table id="eg_table" class="table">
         <thead>
            <tr>
                
                <th>Event Title</th>
                <th>Registered Teams</th>
                <th>Registered Status</th>
               <th></th>
            </tr>
        </thead>
        <tbody>
       	<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><a href="Event/<?php echo e($team->team_id); ?>/<?php echo e($team->tournament_id); ?>">Chicago World Event </a></td>
                <td><a href="<?php echo e(url('/Event $user->team_id')); ?>"><?php echo e($team->team_name); ?></a></td>
                <td><a href="">Incomplete</a></td>
                 <td>
               <a href="viewteamdashboard/<?=$team->team_id?>" class="btn btn-primary btn-block signout-btn">View</a>
                </td>
			      </tr>
                
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
        </tbody>

      </table>
        
    </div>
    </div>

    <footer>
    </footer>   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
