<!DOCTYPE html>
<html>
<head>
	<title>Login Form</title>
</head>
<body><form method="POST" action="">
<label>Name:</label><input type="text" name="Name"><br>
<label>Email:</label><input type="text" name="Email"><br>
<label>Password:</label><input type="Password" name="Password"><br>
<input type="submit" name="submit">
</form>
</body>
</html>