<?php $__env->startSection('bodyContentAdmin'); ?>

<div class="container">
		<h1 style="text-align: center;">TOURNAMENTS SCHEDULE</h1>
		<table id="eg_table" class="table">
		     <thead>
            <tr>
                <th>Event Date</th>
                <th>Event Title</th>
                <th>Registered</th>
                <th>Action</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tournament->tournament_date); ?></td>
                <td><?php echo e($tournament->tournament_name); ?></td>
                <td>% of team accept</td>
               
                <td>
                <a href="editTournament/<?php echo e($tournament->tournament_id); ?>">
                <img class="edit" src="images/pencil.png" title="edit" alt="edit">
                </a>
                <a href="deleteTournament/<?php echo e($tournament->tournament_id); ?>">
                <img class="delete" src="images/cancel.png" title="delete" alt="delete">
                </a>
                </td>

                 <td>
                 <a href="ViewTournament/<?php echo e($tournament->tournament_id); ?>">
                View
                </a>
                </td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
         
        </tbody>

  		</table>
        <a href="addNewTournament">Create New Event</a>
	</div>
	<footer>
	</footer>	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
<script>
		$(document).ready(function() {
    $('#eg_table').DataTable({

    	"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
} );
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainFrameAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>